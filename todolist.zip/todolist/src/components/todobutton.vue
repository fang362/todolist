<template>
  <div class="btn-group" role="group" aria-label="Basic example">
    <button
      type="button"
      class="btn"
      :class="active === 0 ? 'btn-primary' : 'btn-secondary'"
      @click="changeActivie(0)"
    >
      全部
    </button>
    <button
      type="button"
      class="btn"
      :class="active === 1 ? 'btn-primary' : 'btn-secondary'"
      @click="changeActivie(1)"
    >
      已完成
    </button>
    <button
      type="button"
      class="btn"
      :class="active === 2 ? 'btn-primary' : 'btn-secondary'"
      @click="changeActivie(2)"
    >
      未完成
    </button>
  </div>
</template>

<script>
export default {
  name: "todoButton",
  data() {
    return {
      // 此时底部显示’全部‘那一栏
      active : 0,
    };
  },
  emits:['changeActive'],
  methods:{
    changeActivie(index){
      this.active=index
      // 子传父
      this.$emit('changeActive',index)
    }
  }
};
</script>

<style scoped>
.btn-group {
  width: 500px;
  margin: 10px auto;
}

</style>