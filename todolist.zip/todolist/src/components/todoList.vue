<template>
  <ul class="list-group">
    <li
      class="list-group-item d-flex justify-content-between align-items-center"
      v-for="item in todoList" :key="item.id"
      >
      <!-- 复选框 -->
      <div class="form-group form-check">
        <input 
          type="checkbox" 
          class="form-check-input" 
          value=""
          v-model="item.isCompleted"
          :id="item.id"/>
        <!-- 上一行什么意思 -->

        <label 
        class="form-check-label"
        :class="item.isCompleted?'deleted':''"
        :for="item.id">
        <!-- 上一行什么意思 -->
          {{ item.task }}
        </label>
      </div>
      <span class="badge badge-primary badge-pill completed"
      v-if="item.isCompleted">已完成</span>
      <span class="badge badge-primary badge-pill notcompleted"
      v-else>未完成</span>
    </li>
  </ul>
</template>

<script>
export default {
  name: "todoList",
  props:{
    todoList:{
      type:Array,
      required:true,
      default:[]
    }
  }
};
</script>

<style scoped>
.list-group {
  width: 500px;
  margin: 0 auto;
}
.form-group{
margin: 0;
}
.notcompleted{
  background-color: red;
}
.completed{
  background-color:gray;
}
.deleted{
  text-decoration: line-through;
}
</style>