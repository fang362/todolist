<template>
  <div class="input-group mb-3">
    <div class="input-group-prepend">
      <span class="input-group-text" id="basic-addon1">新建任务</span>
    </div>
    <input
      type="text"
      class="form-control"
      placeholder="请输入任务"
      aria-label="Username"
      aria-describedby="basic-addon1"
      v-model="taskName"
    />
    <button class="btn-primary" @click="onsubmit">提交</button>
  </div>
</template>

<script>
export default {
  name: "todoInput",
  data(){
    return{
        taskName:''
    }
  },
  emit:['addTask'],
  methods:{
    onsubmit(){
        this.$emit('addTask',this.taskName)
        this.taskName=''
    }
  }
};
</script>

<style scoped>
.input-group {
  width: 500px;
  margin: 10px auto;
}
.btn-primary{
    border: 0;
}
</style>