<template>
  <div id="app">
    <h1>TodoList</h1>
    <todoInput @addTask="addTask"></todoInput>
    <todoList :todoList="todoList"></todoList>
    <todoButton @changeActive="changeActive"></todoButton>
  </div>
</template>

<script>
import todoList from "./components/todoList.vue"
import todoButton from "./components/todobutton.vue"
import todoInput from "./components/todoInput.vue"
export default {
  name: "App",
  data(){
    return{
      todoList:[
        { id: 1, task: "吃饭", isCompleted: false },
        { id: 2, task: "睡觉", isCompleted: false },
        { id: 3, task: "学习", isCompleted: true },
      ],
      active:0
    }
  },
  methods:{
    changeActive(active){
      this.active=active
      console.log(this.active)
    },
    addTask(taskName){
      this.todoList.unshift({
        id:this.todoList.length+1,
        task:taskName,
        isCompleted:false
      })
    }
  },
  computed:{
    todoList(){
      if(this.active===0){
        return this.todoList
      }else if(this.active===1){
        return this.todoList.filter((item)=>item.isCompleted)
      }else {
        return this.todoList.filter((item)=>!item.isCompleted)
       }
    }
  },
  components: {
    todoList,
    todoButton,
    todoInput
  },
};
</script>
<style>
*{
  outline: none;
}
</style>
